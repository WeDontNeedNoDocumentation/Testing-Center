import java.util.Date;
import org.joda.time.DateTime;

/**
 * 
 */

/**
 * @author WdNnD
 *
 */
public class TimeSlot {

	private int[] seats;
	private DateTime start;
	private boolean filled;
	/**
	 * 
	 */
	public TimeSlot() {
		// TODO Auto-generated constructor stub
	}
	
	public TimeSlot(int[] seats, DateTime start, boolean filled) {
		this.seats = seats;
		this.start = start;
		this.filled = filled;
	}
	
	public void displaySeats() {
		
	}
	
	public void dillSeat() {
		
	}
	
	public void emptySeat() {
		
	}
	
	public void isFilled() {
		
	}

}
